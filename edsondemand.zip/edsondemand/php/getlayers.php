<?php 
header('Access-Control-Allow-Origin: *');

//error_reporting(E_ALL);

$request =  'http://services.asascience.com/ecop/wms.aspx?&Request=GetGeospatial&clientkey=999';

// Make the request
$session = curl_init($request); 

$response = curl_exec($session); 
  curl_close($session);

// Output the XML
echo file_get_contents($response);
?>